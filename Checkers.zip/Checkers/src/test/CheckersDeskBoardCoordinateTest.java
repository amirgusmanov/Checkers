package test;


import com.company.Coordinate.Horizontal;
import com.company.Coordinate.Vertical;


public class CheckersDeskBoardCoordinateTest {

    public static void main(String[] args){

        for(int i = 1; i <= Vertical.values().length; i++){
            System.out.println(Vertical.values());
        }
        System.out.println();
        for(int i = 1; i <= Horizontal.values().length; i++){
            System.out.println(Horizontal.values());
        }
        System.out.println();
        System.out.println(Vertical.values().length);

    }
}
