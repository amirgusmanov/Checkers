package com.company.UI;

import com.company.Move.Move;

public interface UserInterface {

    void showDesk();    //метод, которые показывает доску игроку

    Move nextMove();    //метод, возвращающий следующий ход


}
