package com.company.UI;

import com.company.DeskGame.Desk;
import com.company.Move.Move;

import java.util.Scanner;

public class ConsoleUI implements UserInterface {
//basic implementation of the UI interface for computer terminal

    private Scanner scanner;
    private Desk game;

    public ConsoleUI(Scanner scanner, Desk game) {
        this.scanner = scanner;
        this.game = game;
    }

    @Override
    public void showDesk() {

    }

    @Override
    public Move nextMove() {
        return null;
    }
}
