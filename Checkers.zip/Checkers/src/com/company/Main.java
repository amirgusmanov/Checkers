package com.company;

import com.company.Checker.Checker;
import com.company.Coordinate.BoardCoordinate;
import com.company.DeskGame.BasicDesk;
import com.company.DeskGame.Desk;
import com.company.Move.Move;
import com.company.UI.ConsoleUI;
import com.company.UI.UserInterface;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Desk game = new BasicDesk(new ArrayList<>());
        UserInterface ui = new ConsoleUI(new Scanner(System.in), game);

        ui.showDesk();

        while(true) {
            Move nextMove = ui.nextMove();
            game.handle(nextMove);
            ui.showDesk();
        }
    }
}
