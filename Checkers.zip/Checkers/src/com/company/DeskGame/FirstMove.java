package com.company.DeskGame;

import com.company.Checker.Checker;
import com.company.Move.Move;

import java.util.List;

public class FirstMove extends Desk{

    public int NumberOfMoves;

    public FirstMove(List<Checker> checkerList) {
        super(checkerList);
    }

    @Override
    public void handle(Move m) {
        Checker checker = findChecker(m.getStart());
        if(checker.isWhite() && m.getTarget() == m.getStart()){
            NumberOfMoves++;
        }
    }

    public int getNumberOfMoves() {
        return NumberOfMoves;
    }

    public void setNumberOfMoves(int numberOfMoves) {
        NumberOfMoves = numberOfMoves;
    }
}
