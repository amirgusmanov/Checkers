package com.company.DeskGame;

import com.company.Checker.Checker;
import com.company.Coordinate.BoardCoordinate;
import com.company.Exceptions.CheckerNotFoundException;
import com.company.Move.Move;

import java.util.List;

public abstract class Desk {

    private List<Checker> checkerList;

    private boolean isWhiteMove;

    public abstract void handle(Move m);    //функция для реализации хода

    public Desk(List<Checker> checkerList){
        this.checkerList = checkerList;
    }

    public Checker findChecker(BoardCoordinate coordinate){
        for(int i = 0; i < checkerList.size(); i++){
            Checker checker = checkerList.get(i);
            if(checker.getCoordinate().equals(coordinate)){
                return checker;
            }
        }
        throw new CheckerNotFoundException(coordinate);
    }

    public Checker findCheckerOrNull(BoardCoordinate coordinate){
        for(int i = 0; i < checkerList.size(); i++){
            Checker checker = checkerList.get(i);
            if(checker.getCoordinate().equals(coordinate)){
                return checker;
            }
        }
        return null;
    }

    public List<Checker> getCheckerList() {
        return checkerList;
    }

    public void setCheckerList(List<Checker> checkerList) {
        this.checkerList = checkerList;
    }

    public boolean isWhiteMove() {
        return isWhiteMove;
    }

    public void setWhiteMove(boolean whiteMove) {
        isWhiteMove = whiteMove;
    }

}
