package com.company.DeskGame;

import com.company.Checker.Checker;
import com.company.Checker.QueenChecker;
import com.company.Checker.SimpleChecker;
import com.company.Coordinate.BoardCoordinate;
import com.company.Exceptions.ImpossibleMoveException;
import com.company.Exceptions.NotImplementedException;
import com.company.Main;
import com.company.Move.Move;

import java.util.ArrayList;
import java.util.List;

public class BasicDesk extends Desk {

    private Checker eatingSpreeChecker;
    public BasicDesk(List<Checker> checkerList) {
        super(checkerList);
        eatingSpreeChecker = null;
    }

    @Override
    //функция проверяющая возможность хода пешки, учитывая координаты других пешек
    public void handle(Move m) {

        //обязательное съедение пешек
        for(Checker checker : getCheckerList()){
            if(canBeEaten(checker) && checker.isWhite() != isWhiteMove()){
                Checker c = findChecker(eatingSpreeChecker.getCoordinate());
                if(c.canMove(m.getTarget()) && !c.isWhite()){
                    eatingSpreeChecker.equals(c);
                    //have to eat this checker
                    handleEating(m);
                }
            }
        }

        Checker checker = findChecker(m.getStart());
        QueenChecker queenChecker = (QueenChecker) findChecker(m.getStart());

        if (!checker.canMove(m.getTarget())) {
            throw new ImpossibleMoveException(checker, m.getTarget());
        }

        if (checker.isWhite() != this.isWhiteMove()) {
            throw new ImpossibleMoveException(checker, m.getTarget());
        }

        Checker targetChecker = findCheckerOrNull(m.getTarget());
        if (targetChecker != null) {
            if (targetChecker.isWhite() == checker.isWhite()) {
                throw new ImpossibleMoveException(checker, m.getTarget());
            }
            handleEating(m);
        }
        handleSimpleMove(m);
    }

    private boolean canBeEaten(Checker checker){

        if(!getCheckerList().contains(checker)){
            throw new RuntimeException(String.format("Checker {%s} is not on the desk", checker));
        }
        return canBeEatenSimple(checker) || canBeEatenQueen(checker);

    }

    private boolean canBeEatenSimple(Checker checker){

        if(!getCheckerList().contains(checker)){
            throw new RuntimeException(String.format("Checker {%s} is not on the desk", checker));
        }
        List<BoardCoordinate> coordinates = checker.getCoordinate().adjacentCoordinates();
        List<Checker> adjacentCheckers = new ArrayList<>();

        for (BoardCoordinate coordinate : coordinates) {
            Checker c = findCheckerOrNull(coordinate);
            if (c != null)
                adjacentCheckers.add(c);
        }

        List<Checker> adjacentEnemies = new ArrayList<>();
        for (Checker c : adjacentCheckers) {
            if (c.isWhite() != checker.isWhite())
                adjacentEnemies.add(c);
        }
        if (adjacentEnemies.isEmpty()) {
            return false;
        }

        for (Checker enemy : adjacentEnemies) {
            List<BoardCoordinate> diagonals = enemy.getCoordinate().diagonals();
            List<BoardCoordinate> intersections = new ArrayList<>();
            for (BoardCoordinate dp : diagonals) {
                for (BoardCoordinate ap: coordinates) {
                    if (dp.equals(ap))
                        intersections.add(dp);
                }
            }
            if (intersections.isEmpty())
                return true;
        }
        return false;

    }

    private boolean canBeEatenQueen(Checker checker){

        if (!getCheckerList().contains(checker)) {
            throw new RuntimeException(String.format("Checker {%s} is not in the game", checker));
        }

        List<QueenChecker> enemyQueens = new ArrayList<>();

        for (Checker c : getCheckerList()) {
            if (c instanceof QueenChecker && c.isWhite() != checker.isWhite()) {
                enemyQueens.add((QueenChecker) c);
            }
        }

        List<BoardCoordinate> adjacentCoordinates = checker.getCoordinate().adjacentCoordinates();

        for(Checker queen : enemyQueens){
            List<BoardCoordinate> diagonals = queen.getCoordinate().diagonals();
            List<BoardCoordinate> intersections = new ArrayList<>();
            for(BoardCoordinate diagonalCoordinate : diagonals){
                for(BoardCoordinate adjacentCoordinate: adjacentCoordinates){
                    if(diagonalCoordinate.equals(adjacentCoordinate)){
                        intersections.add(adjacentCoordinate);
                    }
                }
            }
            if(intersections.isEmpty()){
                return true;
            }
        }
        return false;
    }

    public void turningIntoAWhiteQueen(Checker checker){

        List<SimpleChecker> basicCheckers = new ArrayList<>();
        List<QueenChecker> queenCheckers = new ArrayList<>();
        basicCheckers.add((SimpleChecker) checker);

        if(checker.getCoordinate().getVertical().getIndex() == 8 && checker.isWhite()){
            basicCheckers.remove(checker);
            queenCheckers.add((QueenChecker) checker);
        }
    }

    public void turningIntoABlackQueen(Checker checker){

        List<SimpleChecker> basicCheckers = new ArrayList<>();
        List<QueenChecker> queenCheckers = new ArrayList<>();
        basicCheckers.add((SimpleChecker) checker);

        if(checker.getCoordinate().getVertical().getIndex() == 1 && !checker.isWhite()){
            basicCheckers.remove(checker);
            queenCheckers.add((QueenChecker) checker);
        }
    }

    private void handleEating(Move m){
        if(eatingSpreeChecker != null){
            if(findChecker(m.getStart()) != eatingSpreeChecker){
                throw new ImpossibleMoveException(findChecker(m.getTarget()), m.getTarget());
            }
        }
        if(canBeEatenSimple(eatingSpreeChecker)) {

        }
        if(canBeEatenQueen(eatingSpreeChecker)) {

        }
    }

    private void handleSimpleMove(Move m){

    }













        /*превращение обычной белой пешки в дамку
        if(checker.isWhite() && checker.canMove(m.getTarget()) && m.getTarget().getTarget().getVertical().getIndex() == 8){
            checker = queenChecker;
        }
        //превращение обычной черной пешки в дамку
        if(!checker.isWhite() && checker.canMove(m.getTarget()) && m.getTarget().getTarget().getVertical().getIndex() == 1){
            checker = queenChecker;
        }*/

}
