package com.company.DeskGame;

import com.company.Checker.Checker;
import com.company.Move.Move;
import com.company.DeskGame.Desk;

import java.util.List;
//
//public class TotalNumberOfPieces extends Desk{
//
//    public TotalNumberOfPieces(List<Checker> checkerList) {
//        super(checkerList);
//    }
//    int numberOfPieces;
//
//    @Override
//    public void handle(Move m) {
//        //общее количество шашек
//        numberOfPieces = getCheckerList().size();
//
//        //подсчет после съедения
//        if(/*...*/){
//            numberOfPieces--;
//        }
//
//    }
//
//    public int getNumberOfPieces() {
//        return numberOfPieces;
//    }
//
//    public void setNumberOfPieces(int numberOfPieces) {
//        this.numberOfPieces = numberOfPieces;
//    }
//}
