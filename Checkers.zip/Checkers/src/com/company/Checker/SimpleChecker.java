package com.company.Checker;

import com.company.Coordinate.BoardCoordinate;
import com.company.Coordinate.BoardPosition;
import com.company.Exceptions.ImpossibleMoveException;

import java.util.List;

public class SimpleChecker extends Checker{

    public SimpleChecker(BoardCoordinate coordinate, boolean isWhite){
        super(isWhite, coordinate);
    }

    //описание хода обычной шашки
    @Override
    public boolean canMove(BoardCoordinate finish) {

        checkBoardCoordinateCompatibilityOrThrowException((BoardCoordinate) finish);
        int deltaVertical = finish.getVertical().getIndex() - this.getCoordinate().getVertical().getIndex();
        int deltaHorizontal = finish.getVertical().getIndex() - this.getCoordinate().getVertical().getIndex();

        if (Math.abs(deltaVertical) != ACCEPTABLE_ABSOLUTE_DELTA_VERTICAL){
            return false;
        }
        if(isWhite()){
            return deltaHorizontal == ACCEPTABLE_ABSOLUTE_DELTA_HORIZONTAL_WHITE;
        }
        else{
            return deltaHorizontal == ACCEPTABLE_ABSOLUTE_DELTA_HORIZONTAL_BLACK;
        }

//        //не может ходить назад по вертикали
//        if (getCoordinate().getTarget().getVertical().getIndex() < getCoordinate().getStart().getVertical().getIndex()){
//            return false;
//        }
//        //не может ходить назад по горизонтали
//        if(getCoordinate().getTarget().getHorizontal().getIndex() < getCoordinate().getStart().getHorizontal().getIndex()){
//            return false;
//        }
//        //не может изменять координату, двигаясь по вертикали больше чем на 1
//        if (getCoordinate().getTarget().getVertical().getIndex() - getCoordinate().getStart().getVertical().getIndex() > 1){
//            return false;
//        }
//        //не может изменять координату, двигаясь по горизонтали больше чем на 1
//        if(getCoordinate().getTarget().getHorizontal().getIndex() - getCoordinate().getStart().getHorizontal().getIndex() > 1){
//            return false;
//        }
//        //не может ходить вперед по ветрикали
//        if(getCoordinate().getTarget().getHorizontal().getIndex() == getCoordinate().getStart().getHorizontal().getIndex()){
//            if(getCoordinate().getTarget().getVertical().getIndex() > getCoordinate().getStart().getVertical().getIndex()){
//                return false;
//            }
//        }
//        //не может ходить горизонтально влево
//        if(getCoordinate().getTarget().getVertical().getIndex() == getCoordinate().getStart().getVertical().getIndex()){
//            if(getCoordinate().getTarget().getHorizontal().getIndex() < getCoordinate().getStart().getHorizontal().getIndex()){
//                return false;
//            }
//        }
//        //не может ходить горизонтально вправо
//        if(getCoordinate().getTarget().getVertical().getIndex() == getCoordinate().getStart().getVertical().getIndex()){
//            if(getCoordinate().getStart().getHorizontal().getIndex() < getCoordinate().getTarget().getHorizontal().getIndex()){
//                return false;
//            }
//        }
    }

    //Разница индексов возможного хода

    public static final int ACCEPTABLE_ABSOLUTE_DELTA_VERTICAL = 1;
    public static final int ACCEPTABLE_ABSOLUTE_DELTA_HORIZONTAL_WHITE = 1;

    public static final int ACCEPTABLE_ABSOLUTE_DELTA_HORIZONTAL_BLACK = -1;

    @Override
    public List<BoardCoordinate> trace(BoardCoordinate target) throws ImpossibleMoveException {
        return null;
    }

}

