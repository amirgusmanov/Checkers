package com.company.Checker;

import com.company.Coordinate.BoardCoordinate;
import com.company.Exceptions.ImpossibleMoveException;

import java.util.List;

public class QueenChecker extends Checker{

    public QueenChecker(boolean isWhite, BoardCoordinate coordinate) {
        super(isWhite, coordinate);
    }

    //описание хода дамки

    @Override
    public boolean canMove(BoardCoordinate finish) {

//        //не может ходить вперед по вертикали
//        if(getCoordinate().getTarget().getHorizontal().getIndex() == getCoordinate().getStart().getHorizontal().getIndex()){
//            if(getCoordinate().getTarget().getVertical().getIndex() > getCoordinate().getStart().getVertical().getIndex()){
//                return false;
//            }
//        }
//        //не может ходить назад по вертикали
//        if(getCoordinate().getTarget().getHorizontal().getIndex() == getCoordinate().getStart().getHorizontal().getIndex()){
//            if(getCoordinate().getTarget().getVertical().getIndex() < getCoordinate().getStart().getVertical().getIndex()){
//                return false;
//            }
//        }
//        //не может ходить горизонтально влево
//        if(getCoordinate().getTarget().getVertical().getIndex() == getCoordinate().getStart().getVertical().getIndex()){
//            if(getCoordinate().getTarget().getHorizontal().getIndex() < getCoordinate().getStart().getHorizontal().getIndex()){
//                return false;
//            }
//        }
//        //не может ходить горизонтально вправо
//        if(getCoordinate().getTarget().getVertical().getIndex() == getCoordinate().getStart().getVertical().getIndex()){
//            if(getCoordinate().getStart().getHorizontal().getIndex() < getCoordinate().getTarget().getHorizontal().getIndex()){
//                return false;
//            }
//        }
//        return true;

        int deltaVertical = finish.getVertical().getIndex() - this.getCoordinate().getVertical().getIndex();
        int deltaHorizontal = finish.getHorizontal().getIndex() - this.getCoordinate().getHorizontal().getIndex();

        return(Math.abs(deltaHorizontal) == Math.abs(deltaVertical) && deltaHorizontal > 0);
    }

    @Override
    public List<BoardCoordinate> trace(BoardCoordinate target) throws ImpossibleMoveException {
        return null;
    }
}
