package com.company.Coordinate;

public interface BoardPosition {

    BoardPosition next();

    BoardPosition previous();

}
